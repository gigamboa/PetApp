package com.gamboa.petapp

import com.google.firebase.database.DatabaseReference

lateinit var Database: DatabaseReference

object Constants {
    @JvmStatic val FIREBASE_ITEM: String = "pet_item"
}