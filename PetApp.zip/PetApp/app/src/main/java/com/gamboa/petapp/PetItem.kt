package com.gamboa.petapp

class PetItem {

    companion object Factory {
        fun create(): PetItem = PetItem()
    }

    var petId: String? = null
    var petName: String? = null
    var status: Boolean? = false
}