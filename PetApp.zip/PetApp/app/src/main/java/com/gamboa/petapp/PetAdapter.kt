package com.gamboa.petapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.Adapter
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.pet_row.view.*

class PetAdapter(private val petList: List<PetItem>, private val context: Context): Adapter<PetAdapter.ViewHolder>() {

    override fun onBindViewHolder (holder: ViewHolder?, position: Int) {

        val pet = petList[position]

        holder?.let {
            it.petName.text = pet.petName
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(context).inflate(R.layout.pet_row, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {

        return petList.size
    }

    class ViewHolder(petView: View): RecyclerView.ViewHolder(petView){

        fun bindView(pet: PetItem){

            val petName = petView.txt_petName

            petName.text = pet.petName
        }

    }
}